# 4A-2: War For San Francisco Trophy

ENGINEERING PROTOTYPE. NOT PHYSICALLY FIT-TESTED.

## Start Here

The trophy is 119.64 x 119.64 x 177.8 mm: exactly 7 inches tall. The slim base scales to 19.26 mm.
The sculpted gold football has a 48 x 26 mm pointed ogive, 13 mm relief, two panel seams and eight curved raised laces.
The 2022, 2023, 2024 and 2025 tags are all installed in the assembled GLB and review 3MF.
Tags are 31.5 x 10.4 mm, with 1.4 mm gold backing and 0.6 mm raised navy lettering.
It has four main pieces and five small labels, for nine physical pieces total.
The four spare rear tag pockets remain empty; there are no extra blank parts.
No Easter eggs are included.

1. Open the five files in Bambu Projects as projects, not flattened meshes.
2. Check printer: Bambu A1, 0.4 mm nozzle. Match navy, silk gold and red to your AMS Lite slots.
3. Replace the generic profiles with your real filament profiles and re-slice.
4. Print the fit coupon and the 2024 tag before a full print.
5. Do not send the supplied G-code directly to the printer without review.

The projects contain Bambu Studio's sliced previews and settings. These are not evidence of a successful physical print.
Single-Part STL contains monochrome fallback geometry. STL does not retain colors.
The GLB is for visual inspection, not a slicing format.

## Fit Coupon

Fit Test contains one peg and a plate with three sockets. Print the plate with its openings facing up.
The sockets run left to right at X = -24, 0, +24 mm, with 0.15, 0.25, 0.35 mm per-side clearances.
The trophy uses the middle allowance, 0.25 mm per side. Changing it requires rebuilding the cup socket.
A 0.52 mm nominal axial allowance is provided in the keyed joint.
This coupon tests the straight key/socket fit, not every pocket or the large bridge sleeve.

## Assembly

1. Remove the cup's underside supports. Keep the open bowl empty.
2. Slide the bridge sleeve over the narrow bottom of the cup BEFORE joining cup and pedestal.
3. Align the bridge's front span, dry-fit, then use small glue dots on the sleeve contact points.
4. Seat the cup on the rectangular pedestal key. Dry-fit and check the front orientation before gluing.
5. Glue the single football panel into its front recess.
6. Attach the title and four winner tags with thin adhesive. Nominal pocket backing allowance is 0.25 mm.

The sleeve has 0.35 mm nominal radial-normal clearance from the cup wall. It needs glue, not force.
Use small amounts of an adhesive tested on scrap PLA. Some CA adhesives can haze dark or silk finishes.
Handle the red sleeve by its bottom ring, not its thin hangers. Silk PLA is not used as a flexing snap.

## Verified Digital Checks

- Each of the nine complete physical parts is a connected, watertight solid with positive volume.
- No detected installed bridge/cup solid interference.
- Every proposed bed layout fits the nominal A1 build volume.
- All five jobs sliced in Bambu Studio 02.08.02.61 using the A1 0.4 mm preset.
- Three walls, 12% gyroid, 0.20 mm layer height; Generic PLA and Generic PLA Silk.
- Slicer-reported total: 8 h 18 min, 181.8 g.
- 9 in-print filament changes, excluding five initial loads.
- Build-plate supports enabled for the cup only. The sleeve has short spans that still need a print test.
- These figures may omit startup and end purge extrusions from machine macros. Purge waste is not physically measured.

## Names And Outstanding Decisions

2022 / THE CHEESEN WON
2023 / ME COLE, HARD MAN
2024 / BUFF BOYS / ALL GROWN UP
2025 / LIL BUFF CHAMPS

The 2024 label uses a shortened three-line layout and omits the trademark mark.
Its final spelling/layout and the small text's legibility need approval and a print test.
The structural joint, sleeve clearance, adhesive thickness and long-term strength are unverified physically.
Display only; not intended for drinking, food contact or hot liquids.

## Assembled Review Model

The assembled 3MF shows the completed trophy with its tags. It is not a single-piece print layout. Use the five separate Bambu projects for printing. The GLB uses Z-up coordinates for this viewer.
